'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';

interface Video {
  id: string;
  tiktok_url: string;
  video_length_seconds: number;
  is_paid: boolean;
}

export default function ViewerPage() {
  const [user, setUser] = useState<any>(null);
  const [currentVideo, setCurrentVideo] = useState<Video | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [watchTime, setWatchTime] = useState(0);
  const [likeClicked, setLikeClicked] = useState(false);
  const [commentClicked, setCommentClicked] = useState(false);
  const [loading, setLoading] = useState(false);
  const [showOverlay, setShowOverlay] = useState(true);
  const [videoStarted, setVideoStarted] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const router = useRouter();

  useEffect(() => {
    // Load user from localStorage
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (!token || !userData) {
      router.push('/');
      return;
    }

    const parsedUser = JSON.parse(userData);
    setUser(parsedUser);

    if (!parsedUser.onboarding_completed) {
      router.push('/viewer/onboarding');
      return;
    }

    // Load first video
    loadNextVideo();
  }, []);

  useEffect(() => {
    // Timer for watch time
    if (videoStarted && currentVideo && showOverlay) {
      timerRef.current = setInterval(() => {
        setWatchTime(prev => {
          const newTime = prev + 1;
          
          // Remove overlay after video duration
          if (newTime >= currentVideo.video_length_seconds) {
            setShowOverlay(false);
            if (timerRef.current) {
              clearInterval(timerRef.current);
            }
          }
          
          return newTime;
        });
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [videoStarted, currentVideo, showOverlay]);

  const loadNextVideo = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/videos/next', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });

      const data = await response.json();

      if (data.requiresOnboarding) {
        router.push('/viewer/onboarding');
        return;
      }

      if (data.onCooldown) {
        alert(`You're on cooldown! Follow promoted accounts to reduce cooldown time.`);
        return;
      }

      if (data.noVideos) {
        alert('No videos available right now. Check back soon!');
        return;
      }

      if (data.success) {
        setCurrentVideo(data.video);
        setSessionId(data.sessionId);
        setWatchTime(0);
        setLikeClicked(false);
        setCommentClicked(false);
        setShowOverlay(true);
        setVideoStarted(false);
      }
    } catch (error) {
      console.error('Error loading video:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePlayClick = () => {
    setVideoStarted(true);
  };

  const handleLikeClick = async () => {
    if (!currentVideo || !sessionId) return;

    // Open TikTok to like
    window.open(currentVideo.tiktok_url, '_blank');

    // Track the action
    const token = localStorage.getItem('token');
    await fetch('/api/actions/like', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        video_id: currentVideo.id,
        session_id: sessionId,
      }),
    });

    setLikeClicked(true);
  };

  const handleCommentClick = async () => {
    if (!currentVideo || !sessionId || !likeClicked) return;

    // Open TikTok to comment
    window.open(currentVideo.tiktok_url, '_blank');

    // Track the action
    const token = localStorage.getItem('token');
    await fetch('/api/actions/comment', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`,
      },
      body: JSON.stringify({
        video_id: currentVideo.id,
        session_id: sessionId,
      }),
    });

    setCommentClicked(true);
  };

  const handleComplete = async () => {
    if (!currentVideo || !sessionId) return;

    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const watchCompleted = watchTime >= (currentVideo.video_length_seconds * 0.9);
      
      const response = await fetch('/api/videos/view', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          video_id: currentVideo.id,
          session_id: sessionId,
          watch_seconds: watchTime,
          watch_completed: watchCompleted,
          like_clicked: likeClicked,
          comment_clicked: commentClicked,
        }),
      });

      const data = await response.json();

      if (data.success) {
        // Update user points in localStorage
        const userData = JSON.parse(localStorage.getItem('user') || '{}');
        userData.points_balance = data.newBalance;
        localStorage.setItem('user', JSON.stringify(userData));
        setUser(userData);

        // Show points earned
        alert(`${data.isAbandonment ? 'Penalty' : 'Earned'}: ${data.pointsEarned} points!\nNew balance: ${data.newBalance}`);

        // Load next video
        loadNextVideo();
      }
    } catch (error) {
      console.error('Error completing video:', error);
    } finally {
      setLoading(false);
    }
  };

  const progress = currentVideo 
    ? Math.min((watchTime / currentVideo.video_length_seconds) * 100, 100)
    : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950">
      {/* Header */}
      <header className="glass-dark border-b border-dark-700">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold text-white">TikRewards</h1>
          <div className="flex items-center gap-4">
            <div className="px-4 py-2 bg-dark-800 rounded-xl">
              <span className="text-sm text-gray-400">Points: </span>
              <span className="text-lg font-bold text-primary-500">{user?.points_balance || 0}</span>
            </div>
            <button
              onClick={() => router.push('/creator')}
              className="px-4 py-2 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition"
            >
              Submit Video
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-4xl mx-auto px-4 py-8">
        {loading && !currentVideo ? (
          <div className="text-center py-20">
            <div className="animate-spin w-12 h-12 border-4 border-primary-500 border-t-transparent rounded-full mx-auto mb-4" />
            <p className="text-gray-400">Loading next video...</p>
          </div>
        ) : currentVideo ? (
          <div className="space-y-6">
            {/* Video Player */}
            <div className="glass-dark rounded-2xl overflow-hidden">
              <div className="relative bg-black aspect-[9/16] max-w-md mx-auto">
                {/* TikTok Embed Placeholder */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <svg className="w-20 h-20 text-gray-600 mx-auto mb-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 20.1a6.34 6.34 0 0010.86-4.43v-7a8.16 8.16 0 004.77 1.52v-3.4a4.85 4.85 0 01-1-.1z"/>
                    </svg>
                    <p className="text-gray-500">TikTok Video</p>
                    <p className="text-xs text-gray-600 mt-2">Video ID: {currentVideo.id.substring(0, 8)}</p>
                  </div>
                </div>

                {/* Overlay - blocks interaction for first 15 seconds */}
                {showOverlay && (
                  <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-10">
                    {!videoStarted ? (
                      <button
                        onClick={handlePlayClick}
                        className="w-20 h-20 rounded-full bg-primary-500 flex items-center justify-center hover:bg-primary-600 transition shadow-lg"
                      >
                        <svg className="w-10 h-10 text-white ml-1" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z"/>
                        </svg>
                      </button>
                    ) : (
                      <div className="text-center">
                        <div className="w-24 h-24 rounded-full border-4 border-primary-500 border-t-transparent animate-spin mx-auto mb-4" />
                        <p className="text-white text-lg font-semibold">Watching...</p>
                        <p className="text-gray-300 mt-2">{watchTime}s / {currentVideo.video_length_seconds}s</p>
                        <div className="w-64 h-2 bg-dark-700 rounded-full mt-4">
                          <div 
                            className="h-full bg-primary-500 rounded-full transition-all"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-3 gap-4">
              <button
                onClick={handleLikeClick}
                disabled={!videoStarted || showOverlay || likeClicked}
                className={`p-6 rounded-xl text-center transition ${
                  likeClicked 
                    ? 'bg-green-500/20 border-2 border-green-500' 
                    : !videoStarted || showOverlay 
                    ? 'bg-dark-800 border-2 border-dark-700 cursor-not-allowed opacity-50' 
                    : 'bg-dark-800 border-2 border-dark-700 hover:border-primary-500'
                }`}
              >
                <svg className={`w-8 h-8 mx-auto mb-2 ${likeClicked ? 'text-green-500' : 'text-gray-400'}`} fill={likeClicked ? 'currentColor' : 'none'} viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />
                </svg>
                <p className={`font-semibold ${likeClicked ? 'text-green-500' : 'text-white'}`}>Like</p>
                <p className="text-xs text-gray-400 mt-1">+5 pts</p>
              </button>

              <button
                onClick={handleCommentClick}
                disabled={!likeClicked || commentClicked}
                className={`p-6 rounded-xl text-center transition ${
                  commentClicked 
                    ? 'bg-green-500/20 border-2 border-green-500' 
                    : !likeClicked 
                    ? 'bg-dark-800 border-2 border-dark-700 cursor-not-allowed opacity-50' 
                    : 'bg-dark-800 border-2 border-dark-700 hover:border-primary-500'
                }`}
              >
                <svg className={`w-8 h-8 mx-auto mb-2 ${commentClicked ? 'text-green-500' : 'text-gray-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
                <p className={`font-semibold ${commentClicked ? 'text-green-500' : 'text-white'}`}>Comment</p>
                <p className="text-xs text-gray-400 mt-1">+10 pts</p>
              </button>

              <button
                onClick={handleComplete}
                disabled={showOverlay || loading}
                className={`p-6 rounded-xl text-center transition ${
                  !showOverlay && !loading
                    ? 'bg-gradient-to-br from-primary-500 to-primary-600 hover:shadow-lg hover:shadow-primary-500/50'
                    : 'bg-dark-800 border-2 border-dark-700 cursor-not-allowed opacity-50'
                }`}
              >
                <svg className="w-8 h-8 text-white mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
                <p className="font-semibold text-white">Next Video</p>
                <p className="text-xs text-gray-200 mt-1">Submit</p>
              </button>
            </div>

            {/* Points Breakdown */}
            <div className="glass-dark rounded-xl p-6">
              <h3 className="text-sm font-semibold text-gray-400 mb-4">Potential Earnings</h3>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Watch complete:</span>
                  <span className={watchTime >= currentVideo.video_length_seconds * 0.9 ? 'text-green-500' : 'text-gray-500'}>
                    +10 pts
                  </span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Like:</span>
                  <span className={likeClicked ? 'text-green-500' : 'text-gray-500'}>+5 pts</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Comment:</span>
                  <span className={commentClicked ? 'text-green-500' : 'text-gray-500'}>+10 pts</span>
                </div>
                <div className="border-t border-dark-700 pt-2 mt-2">
                  <div className="flex justify-between text-sm font-semibold">
                    <span className="text-white">Completion Bonus (1.5x):</span>
                    <span className={
                      watchTime >= currentVideo.video_length_seconds * 0.9 && likeClicked && commentClicked 
                        ? 'text-primary-500' 
                        : 'text-gray-500'
                    }>
                      {watchTime >= currentVideo.video_length_seconds * 0.9 && likeClicked && commentClicked ? '+38 pts' : '---'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-20">
            <p className="text-gray-400">No videos available</p>
          </div>
        )}
      </main>
    </div>
  );
}
