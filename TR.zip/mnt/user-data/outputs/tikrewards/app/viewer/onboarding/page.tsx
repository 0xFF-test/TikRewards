'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

const MAIN_ACCOUNT = '@0xFinanceFirst';

export default function OnboardingPage() {
  const [step, setStep] = useState<'welcome' | 'follow' | 'watch'>('welcome');
  const [videosWatched, setVideosWatched] = useState(0);
  const [hasFollowed, setHasFollowed] = useState(false);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    // Check if user is logged in
    const token = localStorage.getItem('token');
    if (!token) {
      router.push('/');
    }
  }, [router]);

  const handleFollowClick = async () => {
    // Open TikTok profile
    window.open(`https://www.tiktok.com/${MAIN_ACCOUNT}`, '_blank');
    
    // Wait for user to return
    setTimeout(() => {
      setHasFollowed(true);
    }, 2000);
  };

  const handleFollowConfirm = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      
      // Track the follow
      await fetch('/api/actions/follow', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ tiktok_username: MAIN_ACCOUNT }),
      });

      setStep('watch');
    } catch (error) {
      console.error('Follow tracking error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVideoComplete = () => {
    setVideosWatched(prev => prev + 1);
  };

  const handleCompleteOnboarding = async () => {
    setLoading(true);
    try {
      const token = localStorage.getItem('token');
      const user = JSON.parse(localStorage.getItem('user') || '{}');
      
      // In a real implementation, you would call an API to mark onboarding complete
      // For now, we'll update localStorage and redirect
      user.onboarding_completed = true;
      user.followed_main_account = true;
      user.onboarding_videos_watched = 2;
      localStorage.setItem('user', JSON.stringify(user));
      
      router.push('/viewer');
    } catch (error) {
      console.error('Onboarding completion error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950 p-4">
      <div className="max-w-2xl mx-auto pt-12">
        {/* Progress Indicator */}
        <div className="mb-8">
          <div className="flex items-center justify-center space-x-4">
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              step === 'welcome' ? 'bg-primary-500 text-white' : 'bg-dark-700 text-gray-400'
            }`}>
              1
            </div>
            <div className={`h-1 w-20 ${
              step !== 'welcome' ? 'bg-primary-500' : 'bg-dark-700'
            }`} />
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              step === 'follow' ? 'bg-primary-500 text-white' : step === 'watch' ? 'bg-green-500 text-white' : 'bg-dark-700 text-gray-400'
            }`}>
              2
            </div>
            <div className={`h-1 w-20 ${
              step === 'watch' ? 'bg-primary-500' : 'bg-dark-700'
            }`} />
            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
              step === 'watch' && videosWatched >= 2 ? 'bg-green-500 text-white' : step === 'watch' ? 'bg-primary-500 text-white' : 'bg-dark-700 text-gray-400'
            }`}>
              3
            </div>
          </div>
        </div>

        {/* Welcome Step */}
        {step === 'welcome' && (
          <div className="glass-dark rounded-2xl p-8 text-center animate-fade-in">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center shadow-lg shadow-primary-500/30">
              <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold text-white mb-4">Welcome to TikRewards!</h1>
            <p className="text-gray-400 mb-8 max-w-md mx-auto">
              To get started, you'll need to follow our main account and watch 2 videos. 
              This unlocks 2 free video submissions!
            </p>
            <button
              onClick={() => setStep('follow')}
              className="px-8 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
            >
              Get Started
            </button>
          </div>
        )}

        {/* Follow Step */}
        {step === 'follow' && (
          <div className="glass-dark rounded-2xl p-8 text-center animate-fade-in">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center shadow-lg shadow-primary-500/30">
              <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">Follow {MAIN_ACCOUNT}</h2>
            <p className="text-gray-400 mb-8">
              Following our main account gives you a 100% cooldown reduction, meaning you can watch videos continuously!
            </p>
            
            {!hasFollowed ? (
              <button
                onClick={handleFollowClick}
                className="px-8 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
              >
                Open TikTok to Follow
              </button>
            ) : (
              <div className="space-y-4">
                <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
                  <p className="text-green-400">Did you follow {MAIN_ACCOUNT}?</p>
                </div>
                <div className="flex gap-4 justify-center">
                  <button
                    onClick={() => setHasFollowed(false)}
                    className="px-6 py-2 bg-dark-700 text-white rounded-xl hover:bg-dark-600 transition"
                  >
                    No, go back
                  </button>
                  <button
                    onClick={handleFollowConfirm}
                    disabled={loading}
                    className="px-8 py-2 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50"
                  >
                    {loading ? 'Confirming...' : 'Yes, I followed!'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Watch Step */}
        {step === 'watch' && (
          <div className="glass-dark rounded-2xl p-8 text-center animate-fade-in">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-br from-primary-500 to-primary-600 flex items-center justify-center shadow-lg shadow-primary-500/30">
              <svg className="w-10 h-10 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-white mb-4">Watch 2 Videos</h2>
            <p className="text-gray-400 mb-8">
              Watch and engage with 2 videos to complete onboarding. You'll earn points and unlock free submissions!
            </p>
            
            <div className="mb-8">
              <div className="text-6xl font-bold text-primary-500 mb-2">{videosWatched}/2</div>
              <p className="text-gray-400">Videos watched</p>
            </div>

            {videosWatched < 2 ? (
              <div className="space-y-4">
                <button
                  onClick={handleVideoComplete}
                  className="px-8 py-3 bg-gradient-to-r from-primary-500 to-primary-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all"
                >
                  Watch Video {videosWatched + 1}
                </button>
                <p className="text-xs text-gray-500">
                  (In production, this would show actual TikTok videos)
                </p>
              </div>
            ) : (
              <button
                onClick={handleCompleteOnboarding}
                disabled={loading}
                className="px-8 py-3 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50"
              >
                {loading ? 'Completing...' : 'Complete Onboarding 🎉'}
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
