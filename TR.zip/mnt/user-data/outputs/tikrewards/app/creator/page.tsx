'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';

export default function CreatorPage() {
  const [user, setUser] = useState<any>(null);
  const [tiktokUrl, setTiktokUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    
    if (!token || !userData) {
      router.push('/');
      return;
    }

    setUser(JSON.parse(userData));
  }, [router]);

  const handleSubmit = async (isPaid: boolean = false) => {
    setLoading(true);
    setError('');
    setSuccess('');

    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/videos/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          tiktok_url: tiktokUrl,
          is_paid: isPaid,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Submission failed');
        return;
      }

      setSuccess(data.message);
      setTiktokUrl('');
      
      // Refresh user data
      const userResponse = await fetch('/api/users/points', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      const userData = await userResponse.json();
      if (userData.success) {
        localStorage.setItem('user', JSON.stringify(userData.user));
        setUser(userData.user);
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  const canSubmitFree = user.free_submissions_used < 2 && user.points_balance >= 3800;
  const freeSubmissionsLeft = 2 - user.free_submissions_used;

  return (
    <div className="min-h-screen bg-gradient-to-br from-dark-950 via-dark-900 to-dark-950">
      {/* Header */}
      <header className="glass-dark border-b border-dark-700">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <h1 className="text-xl font-bold text-white">TikRewards</h1>
          <div className="flex items-center gap-4">
            <div className="px-4 py-2 bg-dark-800 rounded-xl">
              <span className="text-sm text-gray-400">Points: </span>
              <span className="text-lg font-bold text-primary-500">{user.points_balance}</span>
            </div>
            <button
              onClick={() => router.push('/viewer')}
              className="px-4 py-2 bg-dark-700 text-white rounded-xl hover:bg-dark-600 transition"
            >
              Back to Watching
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-3xl mx-auto px-4 py-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-4">Submit Your Video</h1>
          <p className="text-gray-400 max-w-2xl mx-auto">
            Submit your TikTok video to get it shown to our community of engaged viewers. 
            Free submissions require 3,800 points, or you can pay to skip the queue!
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="glass-dark rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-primary-500 mb-2">{user.points_balance}</div>
            <p className="text-sm text-gray-400">Your Points</p>
          </div>
          <div className="glass-dark rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-green-500 mb-2">{freeSubmissionsLeft}</div>
            <p className="text-sm text-gray-400">Free Slots Left</p>
          </div>
          <div className="glass-dark rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-500 mb-2">3,800</div>
            <p className="text-sm text-gray-400">Points Required</p>
          </div>
        </div>

        {/* Submission Form */}
        <div className="glass-dark rounded-2xl p-8 space-y-6">
          <div>
            <label htmlFor="url" className="block text-sm font-medium text-gray-300 mb-2">
              TikTok Video URL
            </label>
            <input
              id="url"
              type="url"
              value={tiktokUrl}
              onChange={(e) => setTiktokUrl(e.target.value)}
              placeholder="https://www.tiktok.com/@username/video/123456789"
              className="w-full px-4 py-3 bg-dark-800 border border-dark-600 rounded-xl text-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition"
            />
            <p className="text-xs text-gray-500 mt-2">
              Paste the full URL of your TikTok video
            </p>
          </div>

          {error && (
            <div className="p-4 bg-red-500/10 border border-red-500/20 rounded-xl">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          )}

          {success && (
            <div className="p-4 bg-green-500/10 border border-green-500/20 rounded-xl">
              <p className="text-green-400 text-sm">{success}</p>
            </div>
          )}

          {/* Free Submission */}
          <div className="border-t border-dark-700 pt-6">
            <h3 className="text-lg font-semibold text-white mb-4">Free Submission</h3>
            <div className="p-4 bg-dark-800 rounded-xl mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">Cost:</span>
                <span className="text-white font-semibold">3,800 points</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">Wait time:</span>
                <span className="text-white font-semibold">~30 minutes</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Free slots remaining:</span>
                <span className={`font-semibold ${freeSubmissionsLeft > 0 ? 'text-green-500' : 'text-red-500'}`}>
                  {freeSubmissionsLeft}/2
                </span>
              </div>
            </div>
            
            {!canSubmitFree && (
              <div className="p-4 bg-yellow-500/10 border border-yellow-500/20 rounded-xl mb-4">
                <p className="text-yellow-400 text-sm">
                  {freeSubmissionsLeft === 0 
                    ? 'You have used all your free submissions. Please use paid submission.'
                    : `You need ${3800 - user.points_balance} more points to submit.`
                  }
                </p>
              </div>
            )}

            <button
              onClick={() => handleSubmit(false)}
              disabled={loading || !canSubmitFree || !tiktokUrl}
              className="w-full py-3 px-6 bg-gradient-to-r from-green-500 to-green-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Submitting...' : 'Submit for Free'}
            </button>
          </div>

          {/* Paid Submission */}
          <div className="border-t border-dark-700 pt-6">
            <h3 className="text-lg font-semibold text-white mb-4">Paid Submission</h3>
            <div className="p-4 bg-dark-800 rounded-xl mb-4">
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">Cost:</span>
                <span className="text-white font-semibold">$1.00</span>
              </div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-gray-400">Wait time:</span>
                <span className="text-green-500 font-semibold">Instant</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-gray-400">Priority:</span>
                <span className="text-primary-500 font-semibold">Highest</span>
              </div>
            </div>

            <div className="p-4 bg-primary-500/10 border border-primary-500/20 rounded-xl mb-4">
              <p className="text-primary-400 text-sm">
                💡 <strong>Bulk discounts available:</strong> 5+ videos get 10% off, 10+ videos get 25% off, 20+ videos get 50% off!
              </p>
            </div>

            <button
              onClick={() => handleSubmit(true)}
              disabled={loading || !tiktokUrl}
              className="w-full py-3 px-6 bg-gradient-to-r from-primary-500 to-primary-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Processing...' : 'Pay $1 & Submit Now'}
            </button>
          </div>
        </div>

        {/* Important Notes */}
        <div className="mt-8 glass-dark rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4">Important Notes</h3>
          <ul className="space-y-2 text-sm text-gray-400">
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              Each video can only be submitted once, even with payment
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              Videos must be between 15 seconds and 3 minutes long
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              We do not guarantee any specific number of views or engagement
            </li>
            <li className="flex items-start">
              <svg className="w-5 h-5 text-primary-500 mr-2 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              All engagement is organic and performed by real users
            </li>
          </ul>
        </div>
      </main>
    </div>
  );
}
