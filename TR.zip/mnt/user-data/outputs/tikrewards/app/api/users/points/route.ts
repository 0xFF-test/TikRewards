import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest, unauthorizedResponse } from '@/lib/auth';

export async function GET(request: NextRequest) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    
    if (authError || !user) {
      return unauthorizedResponse();
    }

    return NextResponse.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        points_balance: user.points_balance,
        free_submissions_used: user.free_submissions_used,
        onboarding_completed: user.onboarding_completed,
        followed_main_account: user.followed_main_account,
        onboarding_videos_watched: user.onboarding_videos_watched,
      }
    });
  } catch (error) {
    console.error('Get user points error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
