import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest, unauthorizedResponse } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase';
import { isValidTikTokUrl, extractTikTokVideoId, VIDEO, POINTS } from '@/lib/constants';

export async function POST(request: NextRequest) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    
    if (authError || !user) {
      return unauthorizedResponse();
    }

    const { tiktok_url, is_paid = false } = await request.json();

    // Validate TikTok URL
    if (!tiktok_url || !isValidTikTokUrl(tiktok_url)) {
      return NextResponse.json(
        { error: 'Invalid TikTok URL' },
        { status: 400 }
      );
    }

    const videoId = extractTikTokVideoId(tiktok_url);
    if (!videoId) {
      return NextResponse.json(
        { error: 'Could not extract video ID from URL' },
        { status: 400 }
      );
    }

    // Check if video already exists
    const { data: existingVideo } = await supabaseAdmin
      .from('videos')
      .select('*')
      .eq('tiktok_video_id', videoId)
      .single();

    if (existingVideo) {
      return NextResponse.json(
        { error: 'This video has already been submitted' },
        { status: 400 }
      );
    }

    // Check onboarding requirements
    if (!user.onboarding_completed) {
      return NextResponse.json(
        { error: 'Please complete onboarding first' },
        { status: 403 }
      );
    }

    // For free submissions
    if (!is_paid) {
      // Check free submission limit
      if (user.free_submissions_used >= VIDEO.FREE_SUBMISSION_LIMIT) {
        return NextResponse.json(
          { 
            error: `You have used all ${VIDEO.FREE_SUBMISSION_LIMIT} free submissions. Please use paid submission.`,
            requiresPayment: true
          },
          { status: 403 }
        );
      }

      // Check minimum points requirement
      if (user.points_balance < POINTS.MINIMUM_TO_SUBMIT) {
        return NextResponse.json(
          { 
            error: `You need at least ${POINTS.MINIMUM_TO_SUBMIT} points to submit a video. Current balance: ${user.points_balance}`,
            requiredPoints: POINTS.MINIMUM_TO_SUBMIT,
            currentPoints: user.points_balance
          },
          { status: 403 }
        );
      }
    }

    // Create video submission
    const { data: video, error: createError } = await supabaseAdmin
      .from('videos')
      .insert({
        tiktok_url,
        tiktok_video_id: videoId,
        creator_id: user.id,
        status: is_paid ? 'active' : 'pending',
        priority_score: is_paid ? 1000 : 0,
        is_paid,
        activated_at: is_paid ? new Date().toISOString() : null,
      })
      .select()
      .single();

    if (createError) {
      console.error('Error creating video:', createError);
      return NextResponse.json(
        { error: 'Failed to submit video' },
        { status: 500 }
      );
    }

    // If free submission, increment counter
    if (!is_paid) {
      await supabaseAdmin
        .from('users')
        .update({ 
          free_submissions_used: user.free_submissions_used + 1 
        })
        .eq('id', user.id);
    }

    // If free and pending, calculate when it will be activated
    let estimatedWaitMinutes = null;
    if (!is_paid && video.status === 'pending') {
      estimatedWaitMinutes = VIDEO.PAID_WAIT_MINUTES;
      
      // Schedule activation after wait time
      setTimeout(async () => {
        await supabaseAdmin
          .from('videos')
          .update({ 
            status: 'active',
            activated_at: new Date().toISOString() 
          })
          .eq('id', video.id);
      }, VIDEO.PAID_WAIT_MINUTES * 60 * 1000);
    }

    return NextResponse.json({
      success: true,
      video: {
        id: video.id,
        tiktok_url: video.tiktok_url,
        status: video.status,
        is_paid: video.is_paid,
        estimatedWaitMinutes,
      },
      message: is_paid 
        ? 'Video submitted and activated immediately!'
        : `Video submitted! It will be activated in ${estimatedWaitMinutes} minutes.`
    });
  } catch (error) {
    console.error('Video submission error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
