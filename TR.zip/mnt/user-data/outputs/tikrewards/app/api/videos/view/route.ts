import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest, unauthorizedResponse } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase';
import { calculateTotalPoints, calculateAbandonmentPenalty, VIDEO } from '@/lib/constants';

export async function POST(request: NextRequest) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    
    if (authError || !user) {
      return unauthorizedResponse();
    }

    const { 
      video_id, 
      session_id,
      watch_seconds,
      watch_completed,
      like_clicked,
      comment_clicked 
    } = await request.json();

    if (!video_id || !session_id) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Get the view log
    const { data: viewLog, error: viewError } = await supabaseAdmin
      .from('view_logs')
      .select('*')
      .eq('user_id', user.id)
      .eq('video_id', video_id)
      .eq('session_id', session_id)
      .single();

    if (viewError || !viewLog) {
      return NextResponse.json(
        { error: 'View session not found' },
        { status: 404 }
      );
    }

    // Get video details
    const { data: video } = await supabaseAdmin
      .from('videos')
      .select('*')
      .eq('id', video_id)
      .single();

    if (!video) {
      return NextResponse.json(
        { error: 'Video not found' },
        { status: 404 }
      );
    }

    // Calculate points
    const pointsEarned = calculateTotalPoints(watch_completed, like_clicked, comment_clicked);
    
    let finalPoints = pointsEarned;
    let isAbandonment = false;

    // Check for abandonment (0/3 actions completed)
    if (!watch_completed && !like_clicked && !comment_clicked) {
      isAbandonment = true;
      
      // Get abandonment history
      const { data: recentAbandonments } = await supabaseAdmin
        .from('abandonment_logs')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(1);

      const consecutiveCount = recentAbandonments && recentAbandonments.length > 0 
        ? recentAbandonments[0].consecutive_count + 1 
        : 1;

      const penalty = calculateAbandonmentPenalty(consecutiveCount);
      finalPoints = -penalty;

      // Log abandonment
      await supabaseAdmin
        .from('abandonment_logs')
        .insert({
          user_id: user.id,
          video_id,
          consecutive_count: consecutiveCount,
          points_penalty: penalty,
        });
    } else {
      // Reset abandonment streak on any successful action
      // We don't need to do anything here as the streak will naturally reset
    }

    // Ensure points don't go below 0
    const newBalance = Math.max(0, user.points_balance + finalPoints);

    // Update user points
    await supabaseAdmin
      .from('users')
      .update({ points_balance: newBalance })
      .eq('id', user.id);

    // Update view log
    await supabaseAdmin
      .from('view_logs')
      .update({
        watch_seconds,
        watch_completed,
        like_clicked,
        comment_clicked,
        points_awarded: finalPoints,
        completed_at: new Date().toISOString(),
      })
      .eq('id', viewLog.id);

    // Log points transaction
    await supabaseAdmin
      .from('points_logs')
      .insert({
        user_id: user.id,
        action: isAbandonment ? 'abandonment_penalty' : 'video_completion',
        points_change: finalPoints,
        balance_after: newBalance,
        video_id,
        metadata: {
          watch_completed,
          like_clicked,
          comment_clicked,
          watch_seconds,
        },
      });

    // Update video stats
    const updateData: any = {
      total_views: video.total_views + 1,
    };
    if (like_clicked) updateData.total_likes = video.total_likes + 1;
    if (comment_clicked) updateData.total_comments = video.total_comments + 1;

    await supabaseAdmin
      .from('videos')
      .update(updateData)
      .eq('id', video_id);

    // Deactivate session
    await supabaseAdmin
      .from('user_sessions')
      .update({ is_active: false })
      .eq('session_id', session_id);

    return NextResponse.json({
      success: true,
      pointsEarned: finalPoints,
      newBalance,
      isAbandonment,
      completion: {
        watch_completed,
        like_clicked,
        comment_clicked,
      },
    });
  } catch (error) {
    console.error('View completion error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
