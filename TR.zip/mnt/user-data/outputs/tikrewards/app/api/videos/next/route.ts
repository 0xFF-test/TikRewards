import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest, unauthorizedResponse } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase';
import { SESSION } from '@/lib/constants';
import { randomUUID } from 'crypto';

export async function GET(request: NextRequest) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    
    if (authError || !user) {
      return unauthorizedResponse();
    }

    // Check if user needs to complete onboarding
    if (!user.onboarding_completed) {
      return NextResponse.json({
        requiresOnboarding: true,
        message: 'Please complete onboarding first'
      });
    }

    // Check cooldown status
    const { data: cooldownData } = await supabaseAdmin
      .rpc('check_user_cooldown', { p_user_id: user.id });

    if (cooldownData && cooldownData[0]?.on_cooldown) {
      return NextResponse.json({
        onCooldown: true,
        videosWatched: cooldownData[0].videos_watched_in_session,
        cooldownReduction: cooldownData[0].cooldown_reduction_percent,
        message: 'You have reached the viewing limit. Follow promoted accounts to reduce cooldown.'
      });
    }

    // Clean up expired sessions
    await supabaseAdmin
      .from('user_sessions')
      .update({ is_active: false })
      .lt('expires_at', new Date().toISOString());

    // Get next video using the database function
    const { data: nextVideos } = await supabaseAdmin
      .rpc('get_next_video_for_user', { p_user_id: user.id });

    if (!nextVideos || nextVideos.length === 0) {
      // No submitted videos available, could return default TikTok content
      return NextResponse.json({
        noVideos: true,
        useDefaultContent: true,
        message: 'No submitted videos available at this time'
      });
    }

    const nextVideo = nextVideos[0];

    // Create session lock for this video
    const sessionId = randomUUID();
    const expiresAt = new Date(Date.now() + SESSION.TIMEOUT_MINUTES * 60 * 1000);

    const { error: sessionError } = await supabaseAdmin
      .from('user_sessions')
      .insert({
        user_id: user.id,
        video_id: nextVideo.video_id,
        session_id: sessionId,
        expires_at: expiresAt.toISOString(),
        is_active: true,
      });

    if (sessionError) {
      console.error('Error creating session:', sessionError);
    }

    // Create initial view log
    await supabaseAdmin
      .from('view_logs')
      .insert({
        user_id: user.id,
        video_id: nextVideo.video_id,
        session_id: sessionId,
        watch_seconds: 0,
        watch_completed: false,
        like_clicked: false,
        comment_clicked: false,
        points_awarded: 0,
      });

    return NextResponse.json({
      success: true,
      video: {
        id: nextVideo.video_id,
        tiktok_url: nextVideo.tiktok_url,
        video_length_seconds: nextVideo.video_length_seconds || 60, // Default if not set
        is_paid: nextVideo.is_paid,
      },
      sessionId,
      expiresAt: expiresAt.toISOString(),
    });
  } catch (error) {
    console.error('Get next video error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
