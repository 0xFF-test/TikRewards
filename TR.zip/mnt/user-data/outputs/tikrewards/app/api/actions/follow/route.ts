import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest, unauthorizedResponse } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase';
import { MAIN_ACCOUNT } from '@/lib/constants';

export async function POST(request: NextRequest) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    
    if (authError || !user) {
      return unauthorizedResponse();
    }

    const { tiktok_username } = await request.json();

    if (!tiktok_username) {
      return NextResponse.json(
        { error: 'TikTok username is required' },
        { status: 400 }
      );
    }

    // Check if already following
    const { data: existingFollow } = await supabaseAdmin
      .from('follow_tracking')
      .select('*')
      .eq('user_id', user.id)
      .eq('tiktok_username', tiktok_username)
      .single();

    if (existingFollow) {
      return NextResponse.json(
        { error: 'You have already followed this account' },
        { status: 400 }
      );
    }

    // Add follow tracking
    await supabaseAdmin
      .from('follow_tracking')
      .insert({
        user_id: user.id,
        tiktok_username,
        verified: false, // Honor system for now
      });

    // If it's the main account, update user
    if (tiktok_username === MAIN_ACCOUNT) {
      await supabaseAdmin
        .from('users')
        .update({ followed_main_account: true })
        .eq('id', user.id);
    }

    // Update promoted account stats if applicable
    await supabaseAdmin
      .from('promoted_accounts')
      .update({ total_follows: supabaseAdmin.raw('total_follows + 1') })
      .eq('tiktok_username', tiktok_username);

    return NextResponse.json({
      success: true,
      message: 'Follow action tracked successfully'
    });
  } catch (error) {
    console.error('Follow action error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
