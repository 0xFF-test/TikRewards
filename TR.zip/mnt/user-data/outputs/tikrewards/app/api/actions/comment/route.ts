import { NextRequest, NextResponse } from 'next/server';
import { getUserFromRequest, unauthorizedResponse } from '@/lib/auth';
import { supabaseAdmin } from '@/lib/supabase';

export async function POST(request: NextRequest) {
  try {
    const { user, error: authError } = await getUserFromRequest(request);
    
    if (authError || !user) {
      return unauthorizedResponse();
    }

    const { video_id, session_id } = await request.json();

    if (!video_id || !session_id) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Update view log to mark comment as clicked
    const { data: viewLog, error: updateError } = await supabaseAdmin
      .from('view_logs')
      .update({ comment_clicked: true })
      .eq('user_id', user.id)
      .eq('video_id', video_id)
      .eq('session_id', session_id)
      .select()
      .single();

    if (updateError || !viewLog) {
      return NextResponse.json(
        { error: 'Failed to update comment status' },
        { status: 500 }
      );
    }

    return NextResponse.json({
      success: true,
      message: 'Comment action tracked'
    });
  } catch (error) {
    console.error('Comment action error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
